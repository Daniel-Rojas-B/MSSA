﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_2
{
    // Soccer coach training app 
    internal class User
    {
    }
    class Coach : User
    {
    }
    class Player : User
    {
    }
    class Goalkeeper : Player
    {
    }
    class Defender : Player
    {
    }
    class Midfielder : Player
    {
    }
    class Forward : Player
    {
    }
}
