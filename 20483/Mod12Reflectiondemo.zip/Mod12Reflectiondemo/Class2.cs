﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod12Reflectiondemo
{
    // custom attribute
    [DeveloperInfo("Deepali","deepali@gmail.com")]
   // [DeveloperInfo("alex","dsd")]
    internal class Demo
    {
    }
}
