﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment10_3.Data;

namespace Assignment10_3.Data
{
    public static class Records
    {
        public static CarContext carContext;
    }
}
